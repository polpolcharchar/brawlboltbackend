from decimal import Decimal
from boto3.dynamodb.types import TypeDeserializer
import json
import boto3
from datetime import datetime
from DatabaseUtility.gamesUtility import batchWriteGamesToDynamodb, getAllUncachedGames, getMostRecentGame, saveRecentGames
from DatabaseUtility.globalUtility import getDeserializedGlobalStats, getSpecificGlobalStatOverTime
from DatabaseUtility.itemUtility import fullyJSONifyData, prepareItem
from DatabaseUtility.playerUtility import beginTrackingPlayer, compileUncachedStats, getPlayerCompiledStatsJSON, getPlayerInfo, getPlayerStatsObject, updateStatsLastAccessed, updateStatsLastCompiled

import sys
import os



CORS_HEADERS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'OPTIONS,POST',
  'Access-Control-Allow-Headers': 'Content-Type',
}


DYNAMODB_REGION = 'us-west-1'
# GAMES_TABLE_NAME = "BrawlStarsGames"
# playerCompiledStatsTable = 'BrawlStarsPlayers2'
# playerInfoTable = 'BrawlStarsPlayersInfo'

# Initialize DynamoDB client
dynamodb = boto3.client("dynamodb", region_name=DYNAMODB_REGION)

#Update this
# def getDeserializedPlayerCompiledStats(playerTag):
#     response = dynamodb.query(
#             TableName=playerCompiledStatsTable,
#             KeyConditionExpression='playerTag = :playerTag',
#             ExpressionAttributeValues={
#                 ':playerTag': {'S': playerTag},
#             },
#         )
    
#     if len(response['Items']) == 7:
#         deserialized = {}

#         for item in response['Items']:
#             binary = item['stats']['B']

#             statString = item['statType']['S']

#             deserializedItem = pickle.loads(binary)

#             if type(deserializedItem) == dict:
#                 deserialized[statString] = {key: value.to_dict() for key, value in deserializedItem.items()}
#             else:
#                 deserialized[statString] = deserializedItem.to_dict()
        
#         return deserialized
#     else:
#         return None



#API Fetching Functions:




#Function to track recent games:


#Main Logic Functions:


def lambda_handler(event, context):

    eventBody = json.loads(event['body'])

    if eventBody['type'] == 'getGlobalDataOverTime':

        g = getSpecificGlobalStatOverTime(eventBody['statType'], dynamodb)

        if g is None:
            return {
                'statusCode': 502,
                'body': json.dumps({'message': 'Error Loading Global Stats'}),
                'headers': CORS_HEADERS,
            }

        return {
            'statusCode': 200,
            'body': json.dumps(fullyJSONifyData(g)),
            'headers': CORS_HEADERS,
        }

    if eventBody['type'] == 'getGlobalStats':
        g = getDeserializedGlobalStats(dynamodb)

        if g is None:
            return {
                'statusCode': 502,
                'body': json.dumps({'message': 'Error Loading Global Stats'}),
                'headers': CORS_HEADERS,
            }

        return {
            'statusCode': 200,
            'body': json.dumps(g),
            'headers': CORS_HEADERS,
        }

    if eventBody['playerTag'] == "":
        return {
            'statusCode': 502,
            'body': json.dumps({'message': 'Invalid playerTag'}),
            'headers': CORS_HEADERS,
        }
    
    # if the player tag contains the letter o, return error:
    if 'o' in eventBody['playerTag']:
        return {
            'statusCode': 502,
            'body': json.dumps({'message': 'Invalid playerTag: cannot contain the letter o'}),
            'headers': CORS_HEADERS,
        }

    #Standard request 1
    response = getPlayerInfo(eventBody['playerTag'], dynamodb)

    #Begin tracking this player
    if len(response['Items']) == 0:
        trackingResult = beginTrackingPlayer(eventBody['playerTag'], dynamodb)

        if not trackingResult:
            return {
                'statusCode': 502,
                'body': json.dumps({'message': "Tracking Initialization Failed: Player Doesn't Exist"}),
                'headers': CORS_HEADERS,
            }

        response = getPlayerInfo(eventBody['playerTag'], dynamodb)

        # If it is still zero, return error:
        if len(response['Items']) == 0:
            return {
                'statusCode': 502,
                'body': json.dumps({'message': 'Error Adding Player'}),
                'headers': CORS_HEADERS,
            }

    #Test recompiling:
    shouldRecompileStats = False
    lastCompiledDate = datetime.fromisoformat(response["Items"][0]["statsLastCompiled"]["S"])
    shouldRecompileStats = (datetime.now() - lastCompiledDate).days > 3
    if shouldRecompileStats:
        compileUncachedStats(eventBody['playerTag'], dynamodb)
    
    #Standard request 2
    #Update last accessed:
    updateStatsLastAccessed(eventBody['playerTag'], dynamodb)

    resultBody = {
        # "playerInfo": getApiPlayerInfo(eventBody['playerTag'])
        "playerInfo": {"name": response["Items"][0]["username"]["S"]}
    }


    #Standard request 3
    # deserialized = getDeserializedPlayerCompiledStats(eventBody['playerTag'])
    # if deserialized is not None:
    #     resultBody["playerStats"] = deserialized

    stats = getPlayerCompiledStatsJSON(eventBody['playerTag'], dynamodb)
    resultBody["playerStats"] = stats

    return {
        'statusCode': 200,
        'body': json.dumps(resultBody),
        'headers': CORS_HEADERS
    }